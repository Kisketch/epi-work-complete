Paper 1 (61 pages): On the Irrationality of e+pi
Compile with 3 passes of pdflatex 第一阶段_e_plus_pi.tex
