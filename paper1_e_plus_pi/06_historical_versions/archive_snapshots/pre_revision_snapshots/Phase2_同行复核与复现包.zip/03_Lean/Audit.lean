import EpiFormal.Elementary
import EpiFormal.Measure
import EpiFormal.Series
import EpiFormal.FlintHills
import EpiFormal.MeiburgConvergence
import EpiFormal.Alekseyev
import EpiFormal.EulerConvergents
import EpiFormal.AdjacentWitness
import EpiFormal.SignedCriterion
import EpiFormal.Classification
import EpiFormal.Spectrum
import EpiFormal.SignedClusters
import EpiFormal.DefectFibres
import EpiFormal.FactorialCriterion
import EpiFormal.Escape
import EpiFormal.EscapeBoundary
import EpiFormal.EscapeReduction
import EpiFormal.SpectralGap
import EpiFormal.DimHCore
import EpiFormal.DimHFinite
import EpiFormal.DeltaReduction
import EpiFormal.PadeODE
import EpiFormal.PadeIntegral
import EpiFormal.PadeDeriv
import EpiFormal.PadeBoundary
import EpiFormal.PadeRecurrence
import EpiFormal.DeltaSign
import EpiFormal.ThresholdAttained
import EpiFormal.QuarterPointCore
import EpiFormal.QuarterPointTail
import EpiFormal.QuarterPointFinal
import EpiFormal.WeightedFiber
import EpiFormal.WeightedDimHCore
import EpiFormal.WeightedUpper
import EpiFormal.WeightedFinal
import EpiFormal.WeightedLower
import EpiFormal.WeightedCantor

-- 公理审计：仅允许 Axioms/Measure 清单公理 + Lean 基础公理。
-- meiburg_criterion 已由 F2 证明为定理（不再是公理）；全项目零 sorry。
#print axioms vieta_identity
#print axioms quadratic_roots_algebraic
#print axioms at_least_one_transcendental
#print axioms four_numbers_at_most_one_rational
#print axioms mu0_identity
#print axioms tail_summable
#print axioms tail_recurrence
#print axioms irrMeasure_neg
#print axioms irrMeasure_add_rat
#print axioms irrMeasure_mul_rat
#print axioms irrMeasure_inv
#print axioms theoremA_sum
#print axioms theoremA_diff
#print axioms theoremA_prod
#print axioms theoremA_quot
#print axioms proposition_H'
#print axioms meiburg_criterion
#print axioms flint_hills_diverges_bound
#print axioms flint_hills_converges_of_mu_lt
#print axioms circle_spacing
#print axioms dyadic_block_count
#print axioms block_sum_bound
#print axioms sin_nat_ne_zero
#print axioms sin_eventual_lower
#print axioms abs_sub_mul_pi_factor
-- T3 最近整数论证（2026-11-14 修订包更正 1 的形式化）
#print axioms nearest_int_le_four_mul
#print axioms nearest_int_tendsto_atTop
#print axioms term_tendsto_eventually_gt
#print axioms alekseyev_eventual_lower
#print axioms apprPairs_finite_of_flintHills
#print axioms alekseyev_bound
-- 部分联合编译（2026-11-14，A 地基 + F 双指标 + H 符号判据；用户授权）
-- A 地基（EulerConvergents）
#print axioms Qsel_pos
#print axioms Psel_rec
#print axioms Qsel_rec
#print axioms sel_determinant
#print axioms Psel_odd
#print axioms Qsel_odd
#print axioms Qsel_strictMono
#print axioms Qsel_double
#print axioms Qsel_succ_coprime
#print axioms Psel_div_Qsel_tendsto_exp
#print axioms Qsel_tendsto_atTop
-- F 双指标三等价（AdjacentWitness）
#print axioms AdjacentWitness.theorem11_three_equiv
#print axioms AdjacentWitness.pair_iff
#print axioms AdjacentWitness.limit_integer
#print axioms AdjacentWitness.quantitative_bound
#print axioms AdjacentWitness.quantitative_bound_succ
#print axioms AdjacentWitness.hpos_eventually_mismatch
-- H 符号判据（SignedCriterion）
#print axioms EpiFormalH.proposition3_signed_criterion
#print axioms EpiFormalH.proposition3_forward
#print axioms EpiFormalH.proposition3_converse
-- 完整联合编译（2026-11-14，B/C/D/E/G 归一并入；用户授权「全部进行完毕」）
-- B 分类格 + Cor3 间隙（Classification）
#print axioms Classification.theorem2_classification
#print axioms Classification.corollary3_gap
#print axioms Classification.propagate
#print axioms Classification.sel_determinant
-- C 有限谱（Spectrum，无公理）
#print axioms CSpectrum.theorem6_a
#print axioms CSpectrum.theorem6_b
#print axioms CSpectrum.lemma5_four_S_integer
#print axioms CSpectrum.Qsel_pos
-- D 符号聚类（SignedClusters，定理7/8不依赖deltaSel）
#print axioms SignedClusters.theorem7_cluster_set
#print axioms SignedClusters.theorem7_finite
#print axioms SignedClusters.theorem8_realization
-- E 缺陷尾 + 双射（DefectFibres，deltaSel_ne_zero用白名单e_transcendental）
#print axioms DefectFibres.theorem9_tail_iff
#print axioms DefectFibres.corollary10_injective
#print axioms DefectFibres.finer_scale_ratio
#print axioms DefectFibres.control_example
#print axioms DefectFibres.deltaSel_ne_zero
-- G 阶乘判据（FactorialCriterion，无公理）
#print axioms FactorialCriterion.factorial_criterion
#print axioms FactorialCriterion.tFrac_bounds
#print axioms FactorialCriterion.recurrence_u

#print axioms Escape.irrational_iff_inf_mismatch
#print axioms Escape.D_eq_eps
#print axioms EscapeBoundary.boundary_eventual_match
#print axioms Escape.inf_mismatch_iff_eventually
-- Dj 归约链（EscapeReduction，2026-11-15；D2-1~D2-6，仅 deltaSel_tendsto_zero + 基础公理）
#print axioms EscapeReduction.match_eps_bound
#print axioms EscapeReduction.Qsel_pred_div_tendsto_zero
#print axioms EscapeReduction.jQsel_div_Qsel_succ_tendsto
#print axioms EscapeReduction.sharp_bound_tendsto
#print axioms EscapeReduction.match_eventually_eps_le_fifth
#print axioms EscapeReduction.reduction_to_lattice
#print axioms EscapeReduction.P1_imp_irrational
-- 第二阶段：谱隙与水平集维数（SpectralGap，2026-11-15）
#print axioms SpectralGap.apprExponent_eq_zero_iff
#print axioms SpectralGap.spectral_gap
#print axioms SpectralGap.levelSet_below_eq_lattice
#print axioms SpectralGap.latticeL_countable
#print axioms SpectralGap.dimH_levelSet_below
-- 第二阶段维数零覆盖论证核心引理（DimHCore，2026-11-16，仅基础公理）
#print axioms DimHCore.Qsel_ge_factorial
#print axioms DimHCore.Qsel_succ_le
#print axioms DimHCore.fiber_card_le
-- 第二阶段 T-finite 组装（DimHFinite，2026-11-18）
-- 覆盖论证核心：仅基础公理
#print axioms DimHFinite.card_survSet_le
#print axioms DimHFinite.centerOf_mem_survSet
#print axioms DimHFinite.tailSet_cover
#print axioms DimHFinite.tendsto_contentBound
#print axioms DimHFinite.hausdorffMeasure_tailSet_zero
#print axioms DimHFinite.dimH_tailSet_zero
-- 周期性与最终定理：dimH_levelSet_finite 额外依赖两条 deltaSel 公理（OBL-5，经由 c<1/4 分支）
#print axioms DimHFinite.apprExponent_add_intCast
#print axioms DimHFinite.levelSet_subset_iUnion_tailSet
#print axioms DimHFinite.dimH_levelSet_finite
-- OBL-5 第一步：δ 两公理 → 单一符号交替命题的代数归约（DeltaReduction，2026-11-18，仅基础公理）
#print axioms DeltaReduction.deltaSel_rec
#print axioms DeltaReduction.cross_identity
#print axioms DeltaReduction.abs_sum_eq_two
#print axioms DeltaReduction.abs_deltaSel_lt_of_sign
#print axioms DeltaReduction.deltaSel_tendsto_zero_of_sign
-- OBL-5 第二步：Padé 原函数 ODE 与积分表示（PadeODE + PadeIntegral，2026-11-18，仅基础公理）
#print axioms padéR_ode
#print axioms PadeIntegral.pade_integral_repr
-- OBL-5 完成：δ 两条原公理已证为定理（DeltaSign，2026-11-18，仅基础公理）
#print axioms padéP_second_deriv
#print axioms padeI_recurrence
#print axioms DeltaSign.E_eq_I
#print axioms DeltaSign.I_pos
#print axioms DeltaSign.deltaSignAlternation_proved
#print axioms DeltaSign.deltaSel_tendsto_zero_proved
#print axioms DeltaSign.abs_deltaSel_lt_proved
-- OBL-2 解决：阈值 1/4 可达（显式构造点 x0，2026-11-18，仅基础公理）
#print axioms ThresholdAttained.apprSeq_tendsto_quarter
#print axioms QuarterPointFinal.eps_bound
#print axioms QuarterPointFinal.round_eq_M
#print axioms QuarterPointFinal.defect_eventually_one
#print axioms QuarterPointFinal.lambda_x0_eq_quarter
-- OBL-3a 关键零件：加权分支上界（j^{1−α} 标度，2026-11-18，仅基础公理）
#print axioms WeightedFiber.fiber_card_weighted_le
-- OBL-3a 完全闭合：加权相变上界 dimH{Λ_α≤c}≤1−α（2026-11-18，仅基础公理）
#print axioms WeightedDimH.card_wsurvSet_le
#print axioms WeightedUpper.dimH_wtailSet_le
#print axioms WeightedFinal.dimH_levelSetα_le
-- OBL-3b 关键零件：分支下界（Frostman 必需，2026-11-18，仅基础公理）
#print axioms WeightedLower.width_ge
#print axioms WeightedLower.fiber_card_weighted_ge_scale
-- OBL-3b 几何零件：同级区间分离（2026-11-18，仅基础公理）
#print axioms WeightedCantor.winterv_disjoint