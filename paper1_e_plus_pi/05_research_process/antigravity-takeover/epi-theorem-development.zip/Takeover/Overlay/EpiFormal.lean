import EpiFormal.FiniteStateTail
import EpiFormal.PolyWeightedLower
import EpiFormal.Basic
import EpiFormal.GoldenOrbitRigidity
import EpiFormal.WeightedExactDim
import EpiFormal.FullSpectrumDiscrete
import EpiFormal.GoldenOrbitB2Rigidity
import EpiFormal.GaugeNull
import EpiFormal.UnweightedCorrection
import EpiFormal.GaugeExact
import EpiFormal.WindowAndResidueCore
import EpiFormal.GaugeCircle
import EpiFormal.GeneralEndpointRigidity
import EpiFormal.TrichotomyAndPolyExtension
import EpiFormal.PolyGaugeAndPhaseTransition
import EpiFormal.GaugeLiminfComplete
import EpiFormal.FiniteStateGauge
import EpiFormal.PolyWeightedUpper
import EpiFormal.HermiteResiduePeriod


